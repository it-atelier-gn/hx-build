; inherits: ecma
