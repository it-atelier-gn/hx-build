[
  (block)
  (array)
] @fold
