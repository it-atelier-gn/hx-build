[
  (transaction)
  (section)
] @fold
